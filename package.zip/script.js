// Mobile Navigation Toggle
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');

hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('active');
    navMenu.classList.toggle('active');
});

// Close mobile menu when clicking on a link
document.querySelectorAll('.nav-menu a').forEach(link => {
    link.addEventListener('click', () => {
        hamburger.classList.remove('active');
        navMenu.classList.remove('active');
    });
});

// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Navbar background change on scroll
window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        navbar.style.background = 'rgba(25, 25, 50, 0.98)';
    } else {
        navbar.style.background = 'rgba(25, 25, 50, 0.95)';
    }
});

// Intersection Observer for fade-in animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('fade-in');
        }
    });
}, observerOptions);

// Observe all sections for animation
document.querySelectorAll('section').forEach(section => {
    observer.observe(section);
});

// Service card selection
document.querySelectorAll('.service-card .btn').forEach(btn => {
    btn.addEventListener('click', function(e) {
        e.preventDefault();
        
        // Remove active class from all cards
        document.querySelectorAll('.service-card').forEach(card => {
            card.classList.remove('selected');
        });
        
        // Add active class to clicked card
        this.closest('.service-card').classList.add('selected');
        
        // Get service name
        const serviceName = this.closest('.service-card').querySelector('h3').textContent;
        const price = this.closest('.service-card').querySelector('.price').textContent;
        
        // Show selection feedback
        const originalText = this.textContent;
        this.textContent = 'Seçildi ✓';
        this.style.background = '#4caf50';
        
        setTimeout(() => {
            this.textContent = originalText;
            this.style.background = '';
        }, 2000);
        
        // Pre-fill contact form if exists
        const serviceSelect = document.querySelector('select');
        if (serviceSelect) {
            const options = serviceSelect.querySelectorAll('option');
            options.forEach(option => {
                if (option.textContent.includes(serviceName.split(' ')[0])) {
                    option.selected = true;
                }
            });
        }
        
        // Scroll to contact form
        document.querySelector('#contact').scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Contact form handling
const contactForm = document.querySelector('.contact-form');
if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get form data
        const formData = new FormData(this);
        const data = Object.fromEntries(formData);
        
        // Show loading state
        const submitBtn = this.querySelector('button[type="submit"]');
        const originalText = submitBtn.textContent;
        submitBtn.textContent = 'Gönderiliyor...';
        submitBtn.disabled = true;
        
        // Simulate form submission (replace with actual API call)
        setTimeout(() => {
            submitBtn.textContent = 'Gönderildi ✓';
            submitBtn.style.background = '#4caf50';
            
            // Show success message
            const successMessage = document.createElement('div');
            successMessage.innerHTML = `
                <div style="background: #4caf50; color: white; padding: 15px; border-radius: 10px; margin-top: 20px; text-align: center;">
                    <i class="fas fa-check-circle"></i> Randevu talebiniz başarıyla gönderildi! En kısa sürede sizinle iletişime geçeceğim.
                </div>
            `;
            
            this.appendChild(successMessage);
            
            // Reset form
            setTimeout(() => {
                this.reset();
                submitBtn.textContent = originalText;
                submitBtn.style.background = '';
                submitBtn.disabled = false;
                successMessage.remove();
            }, 5000);
            
        }, 2000);
    });
}

// Add some interactive animations
document.querySelectorAll('.service-card').forEach(card => {
    card.addEventListener('mouseenter', function() {
        this.style.transform = 'translateY(-15px) scale(1.02)';
    });
    
    card.addEventListener('mouseleave', function() {
        this.style.transform = this.classList.contains('featured') ? 'scale(1.05)' : 'translateY(0) scale(1)';
    });
});

// Floating animation for tarot cards
const cards = document.querySelectorAll('.card');
cards.forEach((card, index) => {
    card.style.setProperty('--rotation', `${index === 0 ? '-15deg' : index === 2 ? '15deg' : '0deg'}`);
    
    setInterval(() => {
        const randomDelay = Math.random() * 2000;
        setTimeout(() => {
            card.style.transform += ' scale(1.05)';
            setTimeout(() => {
                card.style.transform = card.style.transform.replace(' scale(1.05)', '');
            }, 300);
        }, randomDelay);
    }, 8000);
});

// Parallax effect for hero section
window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    const parallaxElement = document.querySelector('.hero');
    const speed = 0.5;
    
    if (parallaxElement) {
        parallaxElement.style.transform = `translateY(${scrolled * speed}px)`;
    }
});

// Add sparkle effect
function createSparkle() {
    const sparkle = document.createElement('div');
    sparkle.innerHTML = '✨';
    sparkle.style.position = 'fixed';
    sparkle.style.fontSize = '20px';
    sparkle.style.pointerEvents = 'none';
    sparkle.style.zIndex = '9999';
    sparkle.style.left = Math.random() * window.innerWidth + 'px';
    sparkle.style.top = Math.random() * window.innerHeight + 'px';
    sparkle.style.animation = 'sparkleFloat 3s ease-out forwards';
    
    document.body.appendChild(sparkle);
    
    setTimeout(() => {
        sparkle.remove();
    }, 3000);
}

// Add sparkle animation CSS
const sparkleCSS = `
    @keyframes sparkleFloat {
        0% {
            opacity: 1;
            transform: translateY(0px) scale(0);
        }
        50% {
            opacity: 1;
            transform: translateY(-100px) scale(1);
        }
        100% {
            opacity: 0;
            transform: translateY(-200px) scale(0);
        }
    }
`;

const style = document.createElement('style');
style.textContent = sparkleCSS;
document.head.appendChild(style);

// Create sparkles occasionally
setInterval(createSparkle, 5000);

// Welcome message
console.log('🌟 Cosmic Love Tarot websitesine hoş geldiniz! 🌟');
console.log('✨ Aşkınızın yolunu keşfetmeye hazır mısınız? ✨');